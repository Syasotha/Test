import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import{HttpClientModule} from '@angular/common/http';

import{FormsModule}from '@angular/forms';

import { AppRoutingModule } from './/app-routing.module';

import { NavigationComponent } from './navigation/navigation.component';
import { LeaveTypeService } from './Service/leave-type.service';

import { LeaveTypeComponent } from './leave-type/leave-type.component';
import { DepartmentComponent } from './department/department.component';
import { RoleComponent } from './role/role.component';




@NgModule({
  declarations: [
    AppComponent,
    LeaveTypeComponent,
    NavigationComponent,
    DepartmentComponent,
    RoleComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [LeaveTypeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
