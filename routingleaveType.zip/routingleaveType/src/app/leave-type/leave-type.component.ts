import { Component, OnInit } from '@angular/core';
import { LeaveType } from '../Model/leave-type.model';
import { LeaveTypeService } from '../Service/leave-type.service';

@Component({
  selector: 'app-leave-type',
  templateUrl: './leave-type.component.html',
  styleUrls: ['./leave-type.component.css']
})
export class LeaveTypeComponent implements OnInit {
leaveTypeObj:LeaveType=new LeaveType();
leaveTypes:LeaveType[];
 // msg:String;
  constructor(private leaveTypeService:LeaveTypeService) { }

  ngOnInit() {
//this.leaveTypeObj.id=4;
// this.leaveTypeObj.leaveType="medical";
// this.leaveTypeObj.allocationDays=7;
this.getLeaveTypes();
  }
  getLeaveTypes(){
    this.leaveTypeService.getAllLeaveTypes().subscribe(xyz=>{
      console.log(xyz);
      this.leaveTypes=xyz;
    });

  }
  addLeaveType(){
    this.leaveTypeService.createLeaveType(this.leaveTypeObj).subscribe(lmn=>{
      this.getLeaveTypes();
      alert("Leave Type Added");
    });
    
   
  }
//  getLeaveTypeId(leaveType){
//   this.leaveTypeObj=leaveType
//  }

  deleteLeaveType(leaveType){
    console.log(leaveType);
    this.leaveTypeService.deleteLeaveType(leaveType).subscribe(abc=>{        
        this.getLeaveTypes();
        alert("Leave Type Deleted Sucessfully");
    });
   
    //alert(leaveType.id);
  }
  editLeveType(leaveType){
      console.log(leaveType);
      this.leaveTypeObj=Object.assign({},leaveType);
  }

  updateLeaveType(){
    this.leaveTypeService.editLeaveType(this.leaveTypeObj).subscribe(leaveTypes=>{
      this.getLeaveTypes();
      alert("LeaveType Updated");
    });
  }
  //validateAllocationDays(days:number){
    //  if(days>10){
    //    this.msg="You cant type";
    //   }
    //    else{
    //     this.msg="OK";
       
    //  }
  //}

}
