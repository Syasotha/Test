export class LeaveType {
	id:number;
	leaveType:String ;
	allocationDays:number;    
}
