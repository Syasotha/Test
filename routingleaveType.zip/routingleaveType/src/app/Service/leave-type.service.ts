import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LeaveType } from '../Model/leave-type.model';

const httpOption = {
  header: new HttpHeaders({ 'Content.Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class LeaveTypeService {

  constructor(private httpObj: HttpClient) { }

  private leaveTypeUrl = 'http://localhost:8080/leavetype';

  getAllLeaveTypes() {
    return this.httpObj.get<LeaveType[]>(this.leaveTypeUrl);
  }
  getAllLeaveTypesID(leaveType,id) {
    return this.httpObj.get<LeaveType>(this.leaveTypeUrl + "/" +leaveType.id);
  }
  createLeaveType(data) {
    return this.httpObj.post<LeaveType>(this.leaveTypeUrl, data);

  }
  deleteLeaveType(leaveType){
    return this.httpObj.delete(this.leaveTypeUrl + "/" +leaveType.id)
  
  }
  editLeaveType(leaveType){
    return this.httpObj.put<LeaveType>(this.leaveTypeUrl + "/" +leaveType.id,leaveType)
  }

}

