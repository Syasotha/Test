import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule, Routes }  from '@angular/router';

import { LeaveTypeComponent } from './leave-type/leave-type.component';
import { DepartmentComponent } from './department/department.component';
import { RoleComponent } from './role/role.component';

const appRoutes: Routes = [
  { path: 'leaveType', component: LeaveTypeComponent  },
  { path: 'department', component: DepartmentComponent },
  { path: 'role', component:RoleComponent }

];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
